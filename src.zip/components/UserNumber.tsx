const UserNumber = () => {

    return (
        <div className="h-[29px] w-[134px] rounded-[25px] bg-[#827A74] text-[#FFFFFF] text-[14px] py-[5px] px-[10px] flex justify-center items-center font-[Pretendard] font-medium whitespace-nowrap"> 
            익명의 사용자 0322
        </div>
    )
}

export default UserNumber; 